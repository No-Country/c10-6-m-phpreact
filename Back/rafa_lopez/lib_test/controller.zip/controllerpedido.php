<?php
//require_once('./controller/controllerapp.php');
class ControllerPedido extends ControllerApp
{
    public function __construct()
    {
    }
}
