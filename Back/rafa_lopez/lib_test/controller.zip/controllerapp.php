<?php

/**
 * 
 * 
 */
require_once('controllerproducto.php');
require_once('controllermesa.php');
class ControllerApp
{
    protected $db;
    protected $ruta;
    protected $productos = array();
    protected $mesas = array();
    protected $usuario;

    public function __construct()
    {
        //        $this->db = null;
        //$this->mesas;
        //        $this->db = null;
        // $this->db = $this->conectarBD();
    }

    public function setProductos()
    {
        $producto = new ControllerProducto();
        $this->productos[] = $producto->getProducto(($this->db));
    }
    public function getProductos()
    {
        return ($this->productos);
    }
    public function setMesas()
    {
        $mesa = new ControllerMesa();
        $this->mesas[] = $mesa->getMesa(($this->db));
    }
    public function getMesas()
    {
        return ($this->mesas);
    }
    public function conectarBD()
    {
        try {
            // $db = new PDO('mysql:host=localhost:3308;dbname=resto_nocountry', 'root', '');
            $this->db = new PDO('mysql:host=' . SERVER . ';dbname=' . DB, USER, PASS);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->db->exec("SET CHARACTER SET utf8");
        } catch (PDOException $e) {
            echo $e->getMessage();
            exit;
        }
    }
    public function desconectarDB()
    {
        $this->db = null;
    }
    public function getBD()
    {
        //var_dump($this->db);
        return $this->db;
    }
    public function getRuta()
    {
        debug($_GET);
    }
    function respuesta($consulta)
    {
        $consulta = json_encode($consulta);
        header("Content-type: application/json; charset=utf-8");
        header("cache-control: must-revalidate");
        header('Content-Length: ' . strlen($consulta));
        header('Vary: Accept-Encoding');
        echo ($consulta);
    }
}
