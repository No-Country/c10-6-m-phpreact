<?php
//require_once('./controller/controllerapp.php');
class ControllerMesa extends ControllerApp
{
    public function __construct()
    {
    }
    public function   getMesa($conn)
    {
        $sql = "SELECT * FROM mesas";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
}
