<?php
require_once('./controller/controllerapp.php');
public class Inicio()
{
public $app;

public function __construct(){
    $this->app = new ControllerApp();
}

$app->conectarBD();
$app->setProductos();
$app->setMesas();
debug($app->getProductos());
debug($app->getMesas());
$app->desconectarDB();



}