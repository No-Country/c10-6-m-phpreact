<?php
//require_once('./controller/controllerapp.php');
class ControllerUsuario extends ControllerApp
{
    public function __construct()
    {
    }
}
